document.addEventListener("DOMContentLoaded", () => {
  const slider = document.querySelector(".about-slider");
  const slides = Array.from(document.querySelectorAll(".about-slide"));
  const dots = Array.from(document.querySelectorAll(".slider-dot"));
  const previousButton = document.querySelector(".slider-prev");
  const nextButton = document.querySelector(".slider-next");

  if (!slider || slides.length === 0) {
    return;
  }

  let currentSlide = 0;
  let automaticSlider;

  function showSlide(index) {
    slides[currentSlide].classList.remove("active");

    if (dots[currentSlide]) {
      dots[currentSlide].classList.remove("active");
    }

    currentSlide = (index + slides.length) % slides.length;

    slides[currentSlide].classList.add("active");

    if (dots[currentSlide]) {
      dots[currentSlide].classList.add("active");
    }
  }

  function nextSlide() {
    showSlide(currentSlide + 1);
  }

  function previousSlide() {
    showSlide(currentSlide - 1);
  }

  function startAutomaticSlider() {
    clearInterval(automaticSlider);
    automaticSlider = setInterval(nextSlide, 4500);
  }

  nextButton?.addEventListener("click", () => {
    nextSlide();
    startAutomaticSlider();
  });

  previousButton?.addEventListener("click", () => {
    previousSlide();
    startAutomaticSlider();
  });

  dots.forEach((dot, index) => {
    dot.addEventListener("click", () => {
      showSlide(index);
      startAutomaticSlider();
    });
  });

  slider.addEventListener("mouseenter", () => {
    clearInterval(automaticSlider);
  });

  slider.addEventListener("mouseleave", startAutomaticSlider);

  startAutomaticSlider();
});